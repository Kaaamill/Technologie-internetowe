# Technologie-internetowe
Krótki plan działania:
1. Zbudowanie funkcjonalnego szkieletu strony z podstawowymi funkcjami tzn. obsługa użytkowników, dodawanie książek do bazy, filtracja książek.
2. Zbudowanie bazy dla użytkowników i najlepiej dla książek, połączenie z stroną
3. Aspekty wizualne strony, tzn ładne banery itd
4. Dopięcie projektu do końca kwietnia
